
package sys;
public class out {
    private int i,j;
    
    void print2D(double[][] arr)
    {
        for(i=0;i<arr.length;i++)
        {
            for(j=0;j<arr[i].length;j++)
        {
            System.out.print(arr[i][j] + " ");
        }
            System.out.println();
        }
    }
    void printVect(double[] arr2)
    {
        for(i=0;i<arr2.length;i++)
        {
            System.out.println(arr2[i]);
        }
    }
    void printResult(double[] arr3)
    {
       for(i=0;i<arr3.length;i++)
        {
            System.out.println(arr3[i]);
           
        } 
    }
}
