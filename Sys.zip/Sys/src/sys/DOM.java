
package sys;
import static java.lang.Math.abs;
import java.math.*;

public class DOM {
    private int i=0,j=0,k=1;
    boolean dominant(double[][] arr)
    {
        int m = arr.length;
        double [][] arr1 = new double[m][m];
        for(i=0;i<m;i++)
        {
            for(j=0;j<m-1;j++)
        {
            if(Math.abs(arr[i][j]) >= Math.abs(arr[i][j+1] + arr[i][j+2]))
            {
                return true;
            }
            j+=2;
        }
        }
        return false;
        
    }
   
}
