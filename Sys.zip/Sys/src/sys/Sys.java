
package sys;
import java.util.*;
import java.lang.*;
import java.math.*;
public class Sys {

  
    public static void main(String[] args) {
        int tap,k=0,i = 0,j = 0,s = 0;
        String name;
        boolean check = false;
        double[][] arr = new double[s][s]; // matrix arry
        double[] arr2 = new double[s]; // vecteur arry
        double[] arr3 = new double[s]; // result arry
        
        Scanner input = new Scanner(System.in);
        verification vr = new verification();
        DOM dm = new DOM();
        
        remplir rm = new remplir();
        jacobi jac ;
        GaussSidel GSD;
        out pr = new out();
        System.out.println("entrer la dimension de votre System equation :");
        s = input.nextInt();
        vr.getValue(s);
        vr.verif();
        System.out.println("remplir la matrice 2D de dimension de order  " + s + " :");
        arr  = rm.set2D(s);
        System.out.println("votre matrice :");
        pr.print2D(arr);
        System.out.println("remplir vote vec2teur :");
        arr2 = rm.setD(s);
        System.out.println("votre vecteur :");
        pr.printVect(arr2);
        System.out.println("si vous voulez utiliser la methode je jacobi ecrirce 'jacobi' si vous voulez la methode de Gauss-sidel tappez 'GSD'");
        name = input.next();
        tap = 1;
        while(tap != 0)
        {
              if(name.equals("jacobi"))
       {
           //// start verification if the matrix is dominant 
           
           check = dm.dominant(arr);
           if(check == true)
           {
               System.out.println("matrice dominanat vous pouvez continuez");
               arr3 = rm.init(s);
               System.out.println("combien le nombre de Iteration que vous voulez :");
           k = input.nextInt();
           jac = new jacobi();
           jac.jacobi(arr,arr2,arr3,k);

       } else if(check == false)
       {
           System.out.println("votre matrice n'est pas dominnant mais vous pouzez continuez sauf que votre equation peut etre diverge");
       }
           } else if(name.equals("GSD"))
           {
              check = dm.dominant(arr);
           if(check == true)
           {
               System.out.println("matrice dominanat vous pouvez continuez");
               arr3 = rm.init(s);
               System.out.println("combien le nombre de Iteration que vous voulez :");
           k = input.nextInt();
           GSD = new GaussSidel();
           GSD.get(s, k,arr,arr2,arr3);
           GSD.GaussSidel();

           }
           
           }
             System.out.println("si vous voulez utiliser la methode je jacobi ecrirce 'jacobi' si vous voulez la methode de Gauss-sidel tappez 'GSD'");
        name = input.next();
        System.out.println("pour continuer tappez 1 sinon 0 pour sortir");
             tap = input.nextInt();
        }

           }
}


