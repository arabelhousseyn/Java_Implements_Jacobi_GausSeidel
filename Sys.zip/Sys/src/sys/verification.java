
package sys;


public class verification {
    private int s;
    private double[][] arr = new double[s][s];
    void getValue(int s)
    {
        this.s =s;
    }
    void verif()
    {
        try{
            if(s<=0)
            {
              throw new Exception ("Wrong format");   
            }
         
        } catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        
    }
   
}
