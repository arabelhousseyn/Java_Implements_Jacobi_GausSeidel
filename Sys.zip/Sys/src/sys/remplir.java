
package sys;
import java.util.*;
public class remplir {
    private int i,j,s;
    Scanner input = new Scanner(System.in);
    double[][] set2D(int s)
    {
        double[][] arr = new double[s][s];
       for(i=0;i<arr.length;i++)
       {
          for(j=0;j<arr[i].length;j++)
       {
           arr[i][j] = input.nextDouble();
       }
          
       }
       return arr;
    }
    double[] setD(int s)
    {
        double[] arr2 = new double[s];
        for(i=0;i<arr2.length;i++)
        {
            arr2[i] = input.nextDouble();
        }
        return arr2;
    }
    double [] init(int s)
    {
        double [] arr  = new double[s];
        for(i=0;i<s;i++)
        {
           arr[i] = 0;
        }
        return arr;
    }
    
}
