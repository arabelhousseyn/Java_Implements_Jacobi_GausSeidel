
package sys;

public class GaussSidel   {
    private int k,s,i=0,j=0;
    void get (int s,int k,double[][] arr, double[] arr2,double[] arr3)
    {
        this.s = s;
        this.k = k;
        this.arr = arr;
        this.arr2 = arr2;
        this.arr3 = arr3;
    }
    private double[][] arr = new double[s][s];
    private double [] arr2 = new double[s],arr3 = new double[s];
    double[] arr4 = new double[s];
    void GaussSidel()
    {
        int m = arr.length;
        double[] diag;
        diag = new double[m];
        double[] arr4 = new double[m];
        
        for(int r=0;r<s;r++)
        {
            arr4[r] = 0;
        }
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(i == j)
                    {
                       diag[i] = arr[i][j];
                    } 
            }
        }
        for(int f=1;f<=k;f++)
        {
            System.out.println("Iteration " + f+ " :");
            for(i=0;i<m;i++)
            {
                double s =0;
                for(j=0;j<m;j++)
            {
                    if(i != j)
                    {
                        s += arr[i][j]*arr4[j];
                        arr4[i] = (arr2[i] - s) / diag[i];
                        
                    }
            }
               
                System.out.println("x (" + i + " ) = " + arr4[i]);
            }
        }
       
    }
}
