
package sys;

import java.util.Arrays;


public class jacobi  {
    private int f,i=0,j=0;

  
    void jacobi(double[][] arr,double[] arr2,double[] arr3,int k)
    {
        int m = arr.length;
        double[] diag;
       diag = new double[m];
       double[] arr4 = new double[m];
       out o = new out();
       for(int r=0;r<m;r++)
        {
            arr4[r] = 0;
        }
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(i == j)
                    {
                       diag[i] = arr[i][j];
                    } 
            }
        }

       for(f = 1;f<=k;f++)
        {
            System.out.println("Itèration " + f + " :");
            
            for(i=0;i<m;i++)
            {
                double s = 0;
             for(j=0;j<m;j++)
                {
                   if(i != j)
                    {
                        s = (arr[i][j]*arr3[i]);
                    }
                }
             arr3[i] = (arr2[i] - s) / diag[i];
             System.out.println(arr3[i]);
            }
            
            
            
            
            
            
        }
        
        
        
        
      
    }
}
